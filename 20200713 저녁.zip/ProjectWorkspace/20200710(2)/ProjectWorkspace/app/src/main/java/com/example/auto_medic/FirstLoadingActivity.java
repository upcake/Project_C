package com.example.auto_medic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FirstLoadingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_loading);
    }
}
