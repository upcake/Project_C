package com.example.auto_medic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MedicineInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine_info);
    }
}
