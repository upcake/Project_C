package com.example.auto_medic;


import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import net.htmlparser.jericho.Element;
import net.htmlparser.jericho.HTMLElementName;
import net.htmlparser.jericho.Source;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

public class MedicineInfoActivity extends AppCompatActivity {
    private static final String TAG = "MedicineInfoActivity";
    Bitmap bitmap;
    ImageView medicineImg;
    TextView textView1,textView2,textView3,textView4,textView5,textView6,textView7;
    TextView textView8,textView9,textView10,textView11,textView12,textView13,textView14;
    ProgressDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine_info);
        medicineImg = findViewById(R.id.medicineImg);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        textView4 = findViewById(R.id.textView4);
        textView5 = findViewById(R.id.textView5);
        textView6 = findViewById(R.id.textView6);
        textView7 = findViewById(R.id.textView7);
        textView8 = findViewById(R.id.textView8);
        textView9 = findViewById(R.id.textView9);
        textView10 = findViewById(R.id.textView10);
        textView11 = findViewById(R.id.textView11);
        textView12 = findViewById(R.id.textView12);
        textView13 = findViewById(R.id.textView13);
        textView14 = findViewById(R.id.textView14);


        final String data;
        final String[] array = new String[7];
        Intent intent = getIntent();
        data = String.valueOf(intent.getStringExtra("detailName"));
        Log.d(TAG, "파이널이름=>"+data);

        final Handler handler = new Handler();

        dialog = new ProgressDialog(MedicineInfoActivity.this);
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        dialog.setMessage("상세정보 가져오는 중입니다...");
        dialog.setCanceledOnTouchOutside(false);    //바깥쪽을 눌러도 없어지지 않음
        dialog.show();
        new Thread() {

            @Override
            public void run() {
                Log.d(TAG, "run: 1.1단계");
                super.run();
                try {
                    final String[] array = searchMedicine(data);

                    handler.post(new Runnable() {
                        @Override
                        public void run() {

                            //약품 이미지 변경


                            String juso = "https://nedrug.mfds.go.kr/pbp/CCBBB01/getItemDetail?itemSeq=197900277";
                            Source source = null;
                            source = new Source(juso);
                            //System.out.println(source);
                            List<Element> list = source.getAllElements(HTMLElementName.IMG);

                            String data = list.get(1).getAttributeValue("src");
                            System.out.println("jsoup 진입" + data);
                            URL url = null;
                            try {
                                url = new URL(data);
                            } catch (MalformedURLException e) {
                                e.printStackTrace();
                            }
                            Log.d(TAG, "run: "+url);

                            // Web에서 이미지를 가져온 뒤
                            // ImageView에 지정할 Bitmap을 만든다
                            HttpURLConnection conn = null;
                            try {
                                conn = (HttpURLConnection) url.openConnection();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            conn.setDoInput(true); // 서버로 부터 응답 수신
                            try {
                                conn.connect();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            InputStream is = null; // InputStream 값 가져오기
                            try {
                                is = conn.getInputStream();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            bitmap = BitmapFactory.decodeStream(is); // Bitmap으로 변환




                           medicineImg.setImageBitmap(bitmap);






                            //================================================================
                            Log.d(TAG, "핸들러에서 사용: "+Arrays.toString(array));
                            textView2.setText(array[0]);
                            textView4.setText(array[1].replace("|","\n"));
                            textView6.setText(array[2]);
                            textView8.setText(array[3]);
                            textView10.setText(array[4]);
                            textView12.setText(array[5]);
                            textView14.setText(array[6]);

                            dialog.cancel();
                        }
                    });


                } catch (IOException | ParserConfigurationException | SAXException e) {
                    e.printStackTrace();
                }

            }

        }.start();


    }

    //jsoup
    public void jsoup() throws IOException, ParserConfigurationException, SAXException {
        System.out.println("jsoup 진입");
        String juso = "https://nedrug.mfds.go.kr/pbp/CCBBB01/getItemDetail?itemSeq=197900277";

        try {
            new Thread(){
                @Override
                public void run() {
                    super.run();
                    URL url = null;
                    try {
                        url = new URL(juso);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    Source source = null;
                    try {
                        source = new Source(url);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    //System.out.println(source);
                    List<Element> list = source.getAllElements(HTMLElementName.IMG);

                    System.out.println("반복문진입전");
                    for(int i = 0; i < list.size(); i++) {
                        String data = list.get(1).getAttributeValue("src");
                        System.out.println("jsoup 진입"+ data);
                    }
                }

            }.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //약 검색 메소드
    public  String[] searchMedicine(String medicineName) throws IOException, ParserConfigurationException, SAXException {

        StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1471057/MdcinPrductPrmisnInfoService/getMdcinPrductItem"); /*URL*/
        urlBuilder.append("?" + URLEncoder.encode("ServiceKey", "UTF-8") + "=MkSdYE%2Buv%2FKUgV4R8rVZr59Xn0XNCfABz8mQYa9xFwt%2BCigtvqcl2JmkBmpycrnmTdX%2B%2B50a8UNgMqqrB5qvOg%3D%3D"); /*Service Key*/
        urlBuilder.append("&" + URLEncoder.encode("ServiceKey", "UTF-8") + "=" + URLEncoder.encode("MkSdYE%2Buv%2FKUgV4R8rVZr59Xn0XNCfABz8mQYa9xFwt%2BCigtvqcl2JmkBmpycrnmTdX%2B%2B50a8UNgMqqrB5qvOg%3D%3D", "UTF-8")); /*공공데이터포털에서 받은 인증키*/
        urlBuilder.append("&" + URLEncoder.encode("item_name", "UTF-8") + "=" + URLEncoder.encode(medicineName, "UTF-8")); /*품목명*/

        URL url = new URL(urlBuilder.toString());
        Log.d(TAG, "주소: " + url);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Content-type", "application/json");
        System.out.println("Response code: " + conn.getResponseCode());
        BufferedReader rd;

        if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }

        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            sb.append(line);

        }
        rd.close();
        conn.disconnect();
        System.out.println(sb.toString());
        String xmlFile = sb.toString();
        //--------------------
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setIgnoringElementContentWhitespace(true);
        DocumentBuilder builder = factory.newDocumentBuilder();

        Document doc = builder.parse(urlBuilder.toString());

        NodeList list = doc.getElementsByTagName("item");

        String  chart = null;
        String material_name = null;
        String storage_method = null;
        String valid_term = null;
        String ee_doc_data = null;
        String ud_doc_data = null;
        String nb_doc_data = null;

        for(Node node= list.item(0).getFirstChild() ; node !=null ; node=node.getNextSibling()) {
            if(node.getNodeName().equals("CHART")) {
                chart = node.getTextContent();

                Log.d(TAG, "외형정보 : "+chart);
            }
            else if(node.getNodeName().equals("MATERIAL_NAME")) {
                material_name = node.getTextContent();
                Log.d(TAG, "성분정보 : "+material_name);
            }
            else if(node.getNodeName().equals("STORAGE_METHOD")) {
                storage_method = node.getTextContent();
                System.out.println("보관방법 : "+storage_method);
            }
            else if(node.getNodeName().equals("VALID_TERM")) {
                valid_term = node.getTextContent();
                System.out.println("유효기간 : "+valid_term);
            }
            else if(node.getNodeName().equals("EE_DOC_DATA")) {
                ee_doc_data = node.getTextContent();
                ee_doc_data.trim();
                Spanned ex = Html.fromHtml(ee_doc_data);
                System.out.println("효능효과 : "+ee_doc_data);
            }
            else if(node.getNodeName().equals("UD_DOC_DATA")) {
                ud_doc_data = node.getTextContent();
                ud_doc_data.trim();
                System.out.println( "용법용량 : "+ud_doc_data);
               // Spanned ex = Html.fromHtml(nb_doc_data);
            }
            else if(node.getNodeName().equals("NB_DOC_DATA")) {
                nb_doc_data = node.getTextContent();
                nb_doc_data.trim();
                System.out.println("주의사항 : "+nb_doc_data);
               // Spanned ex = Html.fromHtml(nb_doc_data);
            }

        }
        String[] array = new String[0];
        array = new String[]{chart,material_name ,storage_method ,valid_term , ee_doc_data, ud_doc_data,nb_doc_data};

        BufferedReader br = null;

        try {


            // xml 파싱하기
            InputSource is = new InputSource(new StringReader(xmlFile));
            builder = factory.newDocumentBuilder();
            doc = builder.parse(is);
            XPathFactory xpathFactory = XPathFactory.newInstance();
            XPath xpath = xpathFactory.newXPath();
            // XPathExpression expr = xpath.compile("/response/body/items/item");
            XPathExpression expr = xpath.compile("//items/item");
            NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
            NodeList child;
            Node node = null;
            for (int i = 0; i < nodeList.getLength(); i++) {
                child = nodeList.item(i).getChildNodes();
                //System.out.println("---------------------------------------차일드의 개수는"+child.getLength());
                for (int j = 0; j < child.getLength(); j++) {
                    node = child.item(j);

                }


            }



        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
        return array;
    }
}
