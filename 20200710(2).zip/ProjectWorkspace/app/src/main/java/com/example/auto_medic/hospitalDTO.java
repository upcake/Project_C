package com.example.auto_medic;

public class hospitalDTO {
    String name,addr,tel;
    Double longtitude,latitude;

    public hospitalDTO(String name, String addr, String tel, Double longtitude, Double latitude) {
        this.name = name;
        this.addr = addr;
        this.tel = tel;
        this.longtitude = longtitude;
        this.latitude = latitude;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public Double getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(Double longtitude) {
        this.longtitude = longtitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }
}
